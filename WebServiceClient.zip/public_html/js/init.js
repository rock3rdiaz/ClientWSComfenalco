/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

window.App = {};
App.Views = {};
App.Models = {};
App.Collections = {};
App.Utils = {};

window.views = {};
window.models = {};
window.collections = {};


