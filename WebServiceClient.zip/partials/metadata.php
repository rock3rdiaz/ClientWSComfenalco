<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- Bootstrap -->
<link href="public_html/vendors/bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen">
<link href="public_html/vendors/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        
<script type="text/javascript" src="public_html/vendors/jquery/jquery-2.0.3.min.js"></script>
<script type="text/javascript" src="public_html/vendors/bootstrap/js/bootstrap.min.js"></script>

<script type="text/javascript" src="public_html/vendors/backbone/swig.min.js"></script>
<script type="text/javascript" src="public_html/vendors/backbone/underscore-min.js"></script>
<script type="text/javascript" src="public_html/vendors/backbone/backbone-min.js"></script>

<script type="text/javascript" src="public_html/js/utils/Paginator.js"></script>
<script type="text/javascript" src="public_html/js/views/ViewsFactory.js"></script>

<script type="text/javascript" src="public_html/js/init.js"></script>
<script type="text/javascript" src="public_html/js/main.js"></script>



