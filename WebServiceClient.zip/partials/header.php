<div class="jumbotron">
    <div class="row">
        <div class="col-md-3">
            <figure>
                <img class="img-rounded" src="public_html/img/logocomfenalco.jpg" />
            </figure>
        </div>
        
        <div class="col-md-9">
            <h1>Comfenalco Quind&iacute;o</h1>
            <p class="text-success">Zona de consulta en linea</p>           
        </div>
    </div>
</div>